<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>lOgin Form</title>
    <style>
        body{
            
             background: linear-gradient(to right, #bdc3c7, #2c3e50);
        }
        form{
            height: 300px;
            width: 450px;
            background-color: #152121;
            margin: 0px auto;
            border-radius: 25px;
            margin-top: 150px;
            
            
        }
        h1{
            
            color: white;
            text-align: center;
            font-family:sans-serif;
        
            
        
         
            
        }
        input{
            
            
            height: 33px;
            width: 400px;
            border-radius: 10px;
            border: none;
            position: absolute;
            margin-left: 20px;
            margin-top: 10px;
        }
        button{
            width: 120px;
            height: 40px;
            background-color: aqua;
            border-radius: 20px;
            border: none;
            position: absolute;
            margin-left: 140px;
        }
        div{
            width: 450px;
            background-color: white;
            height: 2px;
            position: absolute;
            margin-bottom: 8px;
        }
    </style>
</head>
<body>
    <form action="assignmentdb.php" method="post" enctype="multipart/form-data">
        
        <h1>TELEPHONE DIRECTORY</h1>
        <div>
            
        </div>
        <input type="text" name="fullname" required Placeholder=" Enter Full Name"><br><br><br>
         <input type="text" name="number" required Placeholder=" Enter Contact Number"><br><br><br>
          <input type="Email" name="email" required Placeholder=" Enter Email "><br><br><br><br>
        <button type="submit">Insert</button>
          
    </form>
</body>
</html>