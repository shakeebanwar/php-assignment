<?php

$localhost="localhost";
$dbname="assignment";
$username="root";
$password="";
$conn=mysqli_connect($localhost,$username,$password,$dbname);
if($conn){
    echo "sucessfully";
}
else{
    echo "not sucessfull";
}
$name=$_POST['fullname'];
$number=$_POST['number'];
$email=$_POST['email'];
$sql="insert into info(Name,Contact,Email)values('$name','$number','$email')";
if(mysqli_query($conn,$sql)){

echo "Data Inserted";
    
header('location:assignment2.php');

}


?>



